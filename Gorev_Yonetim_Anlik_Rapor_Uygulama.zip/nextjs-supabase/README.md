# Görev Yönetimi – Ekip Takibi + İş Atama + Anlık Rapor (Next.js + Supabase)

Bu uygulama, senin ihtiyacın olan şu üç şeyi doğrudan karşılar:
- Ekibe iş atama (PM/Hibrit Lider)
- Kimde kaç iş var (WIP) anlık izleme
- Yöneticiye anlık rapor (Dashboard + Reports)

## 1) Supabase Kurulumu
1. Supabase'te yeni proje oluştur
2. SQL Editor'e `supabase/schema.sql` dosyasını yapıştırıp çalıştır
3. Authentication > Providers > Email (Magic Link) açık olsun

## 2) Ortam Değişkenleri
Proje köküne `.env.local` oluştur:
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...

## 3) Çalıştırma
npm install
npm run dev

## 4) Kullanım
- İlk girişte kullanıcı otomatik `profiles` tablosuna yazılır.
- Kullanıcı rollerini (DIRECTOR, HYBRID_LEAD, PM, ANALYST) `profiles.role` alanından güncellersin.
- Task oluştururken: ekip + sorumlu (Analist/PM) seçip atarsın.
- Dashboard/Reports sayfaları anlık veriyi gösterir.
